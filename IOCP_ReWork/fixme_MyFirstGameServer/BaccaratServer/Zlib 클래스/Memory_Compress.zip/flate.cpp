// Flate.cpp : implementation file
//

#include "stdafx.h"
#include "zlib.h"
#include "flate.h"
#include "ByteArrayStream.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define	COMP_BUFSIZE		0x1000
#define	UNCOMP_BUFSIZE		0x8000

void CFlate::Deflate(ISequentialStream* pOutput, ISequentialStream* pInput)
{
	z_stream zstm;
	memset(&zstm,0,sizeof(z_stream));

	BYTE zBufIn[UNCOMP_BUFSIZE];
	BYTE zBufOut[COMP_BUFSIZE];

	deflateInit(&zstm, Z_DEFAULT_COMPRESSION);

	int err = Z_OK;
	while ( TRUE )
	{
		ULONG cbRead = 0;
		HRESULT hResult = pInput->Read(zBufIn, sizeof(zBufIn), &cbRead);
		if ( hResult != S_OK || cbRead == 0 )
			break;

		zstm.next_in = (Bytef*)zBufIn;
		zstm.avail_in = (uInt)cbRead;

		while ( TRUE )
		{
			zstm.next_out = (Bytef*)zBufOut;
			zstm.avail_out = sizeof(zBufOut);

			err = deflate(&zstm, Z_SYNC_FLUSH);
			if (err != Z_OK)
				break;

			ULONG cbWrite = sizeof(zBufOut) - zstm.avail_out;
			hResult = pOutput->Write(zBufOut, cbWrite, &cbWrite );
			if ( hResult != S_OK || cbWrite == 0 )
				break;

			if ( zstm.avail_out != 0 )
				break;
		}
	}

	err = deflateEnd(&zstm);
}

void CFlate::Inflate(ISequentialStream* pOutput, ISequentialStream* pInput)
{
	z_stream zstm;
	memset(&zstm,0,sizeof(z_stream));

	BYTE zBufIn[COMP_BUFSIZE];
	BYTE zBufOut[UNCOMP_BUFSIZE];

	inflateInit(&zstm);

	int err = Z_OK;
	while ( TRUE )
	{
		ULONG cbRead = 0;
		HRESULT hResult = pInput->Read(zBufIn, sizeof(zBufIn), &cbRead);
		if ( hResult != S_OK || cbRead == 0 )
			break;

		zstm.next_in = (Bytef*)zBufIn;
		zstm.avail_in = (uInt)cbRead;

		while ( TRUE )
		{
			zstm.next_out = (Bytef*)zBufOut;
			zstm.avail_out = sizeof(zBufOut);

			err = inflate(&zstm, Z_SYNC_FLUSH);
			if (err != Z_OK)
				break;

			ULONG cbWrite = sizeof(zBufOut) - zstm.avail_out;
			hResult = pOutput->Write(zBufOut, cbWrite, &cbWrite );
			if ( hResult != S_OK || cbWrite == 0 )
				break;

			if ( zstm.avail_out != 0 )
				break;
		}
	}

	err = inflateEnd(&zstm);
}

int CFlate::Compress(BYTE* dst, UINT dstLen, const BYTE* src, UINT srcLen)
{
	CBAStreamReader sr(src , srcLen);
	CBAStreamWriter sw(dst , dstLen);

	Deflate(&sw, &sr);

	return sw.m_Pos;
}


int CFlate::Compress(const LPSTR szFileName)
{
	
	CByteArray comp;

	CFile file;
	if(file.Open(szFileName, CFile::modeRead) == FALSE )
	{
		return 0;
	}

	CByteArray ba;
	int nLength = file.GetLength();
	ba.SetSize(file.GetLength());
	file.Read(ba.GetData(), ba.GetSize());

	file.Close();

	CBAStreamReader sr(ba.GetData(), ba.GetSize());
	CBAStreamWriterAuto sw(comp);
	Deflate(&sw, &sr);

	return comp.GetSize();
}

int CFlate::Compress(CByteArray & comp , const LPSTR szFileName)
{
		
	CFile file;
	if(file.Open(szFileName, CFile::modeRead) == FALSE )
	{
		return 0;
	}

	CByteArray ba;
	int nLength = file.GetLength();
	ba.SetSize(file.GetLength());

	file.Read(ba.GetData(), ba.GetSize());
	file.Close();

	CBAStreamReader sr(ba.GetData(), ba.GetSize());
	CBAStreamWriterAuto sw(comp);
	Deflate(&sw, &sr);

	return comp.GetSize();
}

int CFlate::Compress(const BYTE* src, UINT srcLen)
{
	CByteArray comp;

	CBAStreamReader		sr(src , srcLen);
	CBAStreamWriterAuto sw(comp);

	Deflate(&sw, &sr);
	

	return comp.GetSize();
}

int CFlate::UnCompress(BYTE* dst, UINT dstLen, const BYTE* src, UINT srcLen)
{
	CBAStreamReader sr(src , srcLen);
	CBAStreamWriter sw(dst , dstLen);

	Inflate(&sw, &sr);

	return sw.m_Pos;
}


int CFlate::UnCompress(const LPSTR szFileName)
{
	CByteArray comp;
	CByteArray uncomp;

	

	CFile file;
	if(file.Open(szFileName, CFile::modeRead ) == FALSE )
	{
		return 0;
	}
	
	comp.SetSize(file.GetLength());
	file.Read(comp.GetData(), comp.GetSize());
	file.Close();
		
	CBAStreamReader  	sr(comp.GetData() , comp.GetSize());
	CBAStreamWriterAuto sw(uncomp);

	Inflate(&sw, &sr);
	
	return uncomp.GetSize();
}

int CFlate::UnCompress(CByteArray & uncomp , const LPSTR szFileName)
{
	CByteArray comp;
		

	CFile file;
	if(file.Open(szFileName, CFile::modeRead ) == FALSE )
	{
		return 0;
	}
	
	comp.SetSize(file.GetLength());
	file.Read(comp.GetData(), comp.GetSize());
	file.Close();
		
	CBAStreamReader  	sr(comp.GetData() , comp.GetSize());
	CBAStreamWriterAuto sw(uncomp);

	Inflate(&sw, &sr);
	
	return uncomp.GetSize();

}


int CFlate::UnCompress(LPBYTE pBuf , int nSize)
{
	CByteArray uncomp;

	CBAStreamReader  	sr(pBuf , nSize);
	CBAStreamWriterAuto sw(uncomp);

	Inflate(&sw, &sr);
	
	return uncomp.GetSize();

}

int CFlate::UnCompress(const LPSTR szFileName , LPBYTE pBuf , int nSize)
{
	
	CByteArray uncompBuf;
	
	
	CBAStreamReader  	sr(pBuf , nSize);
	CBAStreamWriterAuto sw(uncompBuf);

	Inflate(&sw, &sr);

	FILE * fp;
	fp = fopen(szFileName , "w+b");
	fwrite(uncompBuf.GetData() , 1 , uncompBuf.GetSize() , fp );
	fclose(fp);

	/*CFile file;
	if(file.Open(szFileName, CFile::modeCreate | CFile::modeWrite | CFile::typeBinary |CFile::shareDenyWrite) == FALSE )
	{
		return 0;
	}
	file.Write(uncompBuf.GetData(), uncompBuf.GetSize());
	file.Close();*/
	
	
	return uncompBuf.GetSize();

}



	
