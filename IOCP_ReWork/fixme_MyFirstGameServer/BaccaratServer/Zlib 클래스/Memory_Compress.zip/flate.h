#pragma once

#include "stdafx.h"

class CFlate
{
public:
	CFlate()
	{
	}
	~CFlate()
	{
	}
	int	Compress    (BYTE* dst, UINT dstBufLen, const BYTE* src, UINT srcLen);	////dst�� ����Ʈ �ǰ� , src�� �ִ� ���� �д´� 
	int Compress	(const LPSTR szFileName);
	int Compress	(CByteArray & comp , const LPSTR szFileName);
	int	Compress	(const BYTE* src, UINT srcLen);
	
	int UnCompress  (LPBYTE pBuf , int nSize);
	int	UnCompress  (BYTE* dst, UINT dstBufLen, const BYTE* src, UINT srcLen);	////dst�� ����Ʈ �ǰ� , src�� �ִ� ���� �д´� 
	int	UnCompress  (const LPSTR szFileName);
	int UnCompress  (const LPSTR szFileName , LPBYTE pBuf , int nSize);
	int UnCompress  (CByteArray & uncomp , const LPSTR szFileName);
	

private:

	void Inflate(ISequentialStream* pOutput, ISequentialStream* pInput);
	void Deflate(ISequentialStream* pOutput, ISequentialStream* pInput);

	
};

