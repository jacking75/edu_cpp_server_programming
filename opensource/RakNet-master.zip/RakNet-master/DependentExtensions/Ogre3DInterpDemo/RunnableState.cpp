#include "RunnableState.h"



void RunnableState::SetParentApp(AppInterface *parent)
{
	this->parent=parent;
}
void RunnableState::SetFocus(bool hasFocus)
{

}
void RunnableState::OnStateReady(void)
{

}
