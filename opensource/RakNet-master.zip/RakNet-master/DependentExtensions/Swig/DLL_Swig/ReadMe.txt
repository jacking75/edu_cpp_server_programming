Swig is required for this solution, see the online swig tutorial on instructions on installing it.

For this solution the path variable needs to be set for swig.

Before the project is ran, Swig is run to generate the CXX file.

After the project is ran the dll is copied to the C# sample.
