Project: SQLite3, SQLite3ClientLogger, SQLite3ServerLogger

Description: SQLite3 just passes calls to sqlite3_exec over the network. Replacement for LightweightDatabaseServer. SQLite3ClientLogger and SQLite3ServerLogger extend this to using an SQLite database for logging. 

Dependencies: http://www.sqlite.org version 3

Related projects: None

For help and support, please visit http://www.jenkinssoftware.com

See also:
http://www.sqlite.org/quickstart.html
http://www.sqlite.org/c3ref/open.html
http://www.sqlite.org/c3ref/free_table.html
http://www.sqlite.org/c3ref/exec.html
