This is the DirectX Matrices sample included with DirectX9.

I use it to copy the backbuffer to main memory, in order to send it to SQLiteClientLoggerPlugin