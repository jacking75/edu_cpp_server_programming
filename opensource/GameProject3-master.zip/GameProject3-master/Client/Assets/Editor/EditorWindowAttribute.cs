﻿using UnityEngine;
using System.Collections;
using System;

namespace EDT
{
    public class EditorWindowAttribute : Attribute
    {
        public string Title = string.Empty;
    }
}