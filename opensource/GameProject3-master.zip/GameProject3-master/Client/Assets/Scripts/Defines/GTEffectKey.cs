﻿using UnityEngine;
using System.Collections;

public class GTEffectKey
{
    public const int EFFECT_TOUCH   = 65001;
    public const int EFFECT_UPGRADE = 65006;
}
