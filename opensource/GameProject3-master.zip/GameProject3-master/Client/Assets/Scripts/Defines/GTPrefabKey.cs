﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class GTPrefabKey
{
    public const string PRE_BARRIER      = "Model/Other/Barrier";
    public const string PRE_PORTALEFFECT = "Model/Other/PortalEffect";
    public const string PRE_UIBOARD      = "Guis/Board/UIBoard";
}