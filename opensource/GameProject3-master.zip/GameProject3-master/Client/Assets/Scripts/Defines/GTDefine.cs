﻿using System;
using System.Collections.Generic;


public class GTDefine
{
    public const Single V_INTERVAL_FINDENEMY      = 0.5f;
    public const Single V_INTERVAL_VALUE          = 0.001f;
    public const Single V_DAMAGE_RATIO            = 1f;

    public const int    RECOVER_COST_ITEM_ID      = 2;      //复活消耗货币ID
    public const int    RECOVER_COST_ITEM_NUM     = 50;     //复活消耗货币数量
}
