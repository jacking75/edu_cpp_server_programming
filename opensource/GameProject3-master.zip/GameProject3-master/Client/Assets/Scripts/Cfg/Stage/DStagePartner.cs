﻿using UnityEngine;
using System.Collections;

public class DStagePartner : DStage
{

}

public class ReadCfgStagePartner : DReadBase<int, DStagePartner>
{

}