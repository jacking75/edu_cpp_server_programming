﻿using UnityEngine;
using System.Collections;

public class DStageMount : DStage
{

}

public class ReadCfgStageMount : DReadBase<int, DStageMount>
{

}