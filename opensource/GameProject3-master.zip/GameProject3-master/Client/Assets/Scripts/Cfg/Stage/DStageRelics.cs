﻿using UnityEngine;
using System.Collections;

public class DStageRelics : DStage
{

}

public class ReadCfgStageRelics : DReadBase<int, DStageRelics>
{

}
