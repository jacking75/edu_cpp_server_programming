﻿using UnityEngine;
using System.Collections;

public class DStageRole : DStage
{

}


public class ReadCfgStageRole : DReadBase<int, DStageRole>
{

}
