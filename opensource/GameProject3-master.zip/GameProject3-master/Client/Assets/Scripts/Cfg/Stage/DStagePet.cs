﻿using UnityEngine;
using System.Collections;

public class DStagePet : DStage
{

}

public class ReadCfgStagePet : DReadBase<int, DStagePet>
{

}