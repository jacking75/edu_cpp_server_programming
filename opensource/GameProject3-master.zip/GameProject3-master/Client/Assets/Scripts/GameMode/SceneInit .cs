﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

public sealed class SceneInit : IScene
{
    public override void OpenWindows()
    {

    }
}
