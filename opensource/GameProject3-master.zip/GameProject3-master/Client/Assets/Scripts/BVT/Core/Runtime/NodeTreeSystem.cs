﻿using UnityEngine;
using System.Collections;
using BVT;
using System.Collections.Generic;
using System;

namespace BVT
{
    public class NodeTreeSystem
    {
        public void Execute()
        {

        }

        public void Release()
        {
      
        }
    }
}