﻿using UnityEngine;
using System.Collections;

public class GTLogTag
{
    public const string TAG_ACTOR = "TAG_ACTOR";
}
