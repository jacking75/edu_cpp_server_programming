﻿using UnityEngine;
using System.Collections;

public class GTItem
{
    public int Id;
    public int Num;

    public GTItem()
    {

    }

    public GTItem(int id, int num)
    {
        this.Id = id;
        this.Num = num;
    }
}