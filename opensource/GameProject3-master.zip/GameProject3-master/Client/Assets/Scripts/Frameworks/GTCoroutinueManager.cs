﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;
using System.Diagnostics;
using System.Text;

public class GTCoroutinueManager : GTMonoSingleton<GTCoroutinueManager>
{

}