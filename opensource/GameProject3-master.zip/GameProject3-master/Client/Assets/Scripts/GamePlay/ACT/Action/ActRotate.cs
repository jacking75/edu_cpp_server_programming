﻿using UnityEngine;
using System.Collections;

namespace ACT
{
    public class ActRotate : ActItem
    {

    }
}

