﻿using UnityEngine;
using System.Collections;
using System;

namespace ACT
{
    public class ActFieldAttribute : Attribute
    {

    }
}

