﻿using UnityEngine;
using System.Collections;
using ACT;

namespace ACT
{
    public class ActShortenSkillCD : ActItem
    {

    }
}

