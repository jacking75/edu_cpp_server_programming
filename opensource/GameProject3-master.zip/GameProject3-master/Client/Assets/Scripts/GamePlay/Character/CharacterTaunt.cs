﻿using UnityEngine;
using System.Collections;

public class CharacterTaunt
{
    public Character CC;
    public int       ThreatValue;
}
