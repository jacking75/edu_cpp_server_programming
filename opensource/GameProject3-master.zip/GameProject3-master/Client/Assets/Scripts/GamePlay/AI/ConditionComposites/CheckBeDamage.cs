﻿using UnityEngine;
using System.Collections;

namespace BVT.AI
{
    [NodeAttribute(Type = "AI/条件组合节点", Label = "CheckBeDamage")]
    public class CheckBeDamage : AICondition
    {

    }
}

