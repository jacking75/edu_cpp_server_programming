﻿using UnityEngine;
using System.Collections;

public class MaskWhiteTransparent : MaskGUI
{

}
