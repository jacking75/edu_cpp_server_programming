﻿using UnityEngine;
using System.Collections;
using System;

public class UINetWaiting : GTWindow
{
    public UINetWaiting()
    {
        Type = EWindowType.Window;
        Resident = true;
        Path = "Login/UINetWaiting";
        MaskType = EWindowMaskType.BlackTransparent;
    }

    protected override void OnAddButtonListener()
    {
        
    }

    protected override void OnAddHandler()
    {
        
    }

    protected override void OnAwake()
    {
        
    }

    protected override void OnClose()
    {
        
    }

    protected override void OnDelHandler()
    {
        
    }

    protected override void OnEnable()
    {
        
    }
}
