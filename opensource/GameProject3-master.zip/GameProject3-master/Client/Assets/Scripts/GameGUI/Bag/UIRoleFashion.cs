﻿using UnityEngine;
using System.Collections;
using System;

public class UIRoleFashion : GTWindow
{
    public UIRoleFashion()
    {
        MaskType = EWindowMaskType.None;
        Type = EWindowType.Window;
        Path = "Bag/UIRoleFashion";
        Resident = false;
        ShowMode = EWindowShowMode.SaveTarget;
    }

    protected override void OnAwake()
    {
        
    }

    protected override void OnAddButtonListener()
    {
       
    }

    protected override void OnAddHandler()
    {
        
    }

    protected override void OnEnable()
    {
        
    }

    protected override void OnDelHandler()
    {
        
    }

    protected override void OnClose()
    {
        
    }
}
