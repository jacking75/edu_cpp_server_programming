﻿using UnityEngine;
using System.Collections;
using System;

public class UIRoleRune : GTWindow
{
    public UIRoleRune()
    {
        MaskType = EWindowMaskType.None;
        ShowMode = EWindowShowMode.SaveTarget;
        Type = EWindowType.Window;
        Path = "Bag/UIRoleRune";
        Resident = false;
    }

    protected override void OnAwake()
    {
        
    }

    protected override void OnAddButtonListener()
    {
      
    }

    protected override void OnAddHandler()
    {
        
    }

    protected override void OnEnable()
    {

    }

    protected override void OnDelHandler()
    {
        
    }


    protected override void OnClose()
    {
       
    }
}
