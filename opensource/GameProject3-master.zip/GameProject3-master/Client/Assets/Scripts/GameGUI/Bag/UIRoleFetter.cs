﻿using UnityEngine;
using System.Collections;
using System;
using System.Collections.Generic;

public class UIRoleFetter : GTWindow
{
    public UIRoleFetter()
    {
        MaskType = EWindowMaskType.None;
        ShowMode = EWindowShowMode.SaveTarget;
        Type = EWindowType.Window;
        Path = "Bag/UIRoleFetter";
        Resident = false;
    }

    protected override void OnAwake()
    {
        
    }

    protected override void OnAddButtonListener()
    {
        
    }

    protected override void OnAddHandler()
    {
        
    }

    protected override void OnEnable()
    {
        
    }

    protected override void OnDelHandler()
    {
        
    }

    protected override void OnClose()
    {
        
    }
}
