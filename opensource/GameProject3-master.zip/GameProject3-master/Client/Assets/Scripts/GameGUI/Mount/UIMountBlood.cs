﻿using UnityEngine;
using System.Collections;
using System;

public class UIMountBlood : GTWindow
{
    public UIMountBlood()
    {
        Type = EWindowType.Window;
        Resident = false;
        Path = "Mount/UIMountBlood";
        MaskType = EWindowMaskType.None;
        ShowMode = EWindowShowMode.SaveTarget;
    }

    protected override void OnAwake()
    {
        
    }

    protected override void OnAddButtonListener()
    {
        
    }

    protected override void OnAddHandler()
    {
        
    }

    protected override void OnEnable()
    {
        
    }

    protected override void OnDelHandler()
    {
        
    }

    protected override void OnClose()
    {
        
    }
}
