﻿using UnityEngine;
using System.Collections;
using System;

public class UIPartnerWash : GTWindow
{
    protected override void OnAwake()
    {
        
    }

    protected override void OnAddButtonListener()
    {
        
    }

    protected override void OnAddHandler()
    {
        
    }

    protected override void OnEnable()
    {
        
    }

    protected override void OnDelHandler()
    {
        
    }

    protected override void OnClose()
    {
        
    }
}
