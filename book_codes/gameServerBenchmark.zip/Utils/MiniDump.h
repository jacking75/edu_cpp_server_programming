#pragma once

class CMiniDump
{
public:
	static VOID Begin(VOID);
	static VOID End(VOID);
};
