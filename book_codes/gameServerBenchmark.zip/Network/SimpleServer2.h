#pragma once

#define MAX_ACCEPT_POOL_CNT 5

template <class TNetObj>
class CSimpleServer2 : public CNetIocp2<TNetObj>
{
public:
	CSimpleServer2(VOID) { m_dwAcceptPoolCnt = MAX_ACCEPT_POOL_CNT; }

	BOOL Begin(USHORT usListenPort)
	{
		InitializeCriticalSection(&m_csAccept);
		InitializeCriticalSection(&m_csConnect);

		//m_poNetIocp = new CNetIocp<TNetObj>();
		m_poListenObj = new TNetObj();

		for (DWORD i=0;i<m_dwAcceptPoolCnt;i++)
		{
			TNetObj *poAcceptObj = new TNetObj();
			m_lstAcceptObj.push_back(poAcceptObj);
		}

		//m_poNetIocp->SetOwnerIocp(this);
		CNetIocp2::SetOwnerIocp(this);
		//if (!m_poNetIocp->Begin(0))
		if (!CNetIocp2::Begin(0))
			return FALSE;

		// Backlog�� AcceptPool�� ������ 10:1�� �����Ѵ�.
		if (!m_poListenObj->Listen(usListenPort, m_dwAcceptPoolCnt * 10))
			return FALSE;

		//if (!m_poNetIocp->RegSocketToIocp(m_poListenObj->GetSocket(), (ULONG_PTR) m_poListenObj))
		if (!CNetIocp2::RegSocketToIocp(m_poListenObj->GetSocket(), (ULONG_PTR) m_poListenObj))
			return FALSE;

		//if (!CIocp::Begin(1))
		//	return FALSE;

		for (std::list<TNetObj*>::iterator it=m_lstAcceptObj.begin();it!=m_lstAcceptObj.end();it++)
		{
			TNetObj *poAcceptObj = (TNetObj*)(*it);
			if (!poAcceptObj->Accept(m_poListenObj->GetSocket()))
				return FALSE;
		}

		return TRUE;
	}

	VOID End(VOID)
	{
		//CIocp::End();

		for (std::list<TNetObj*>::iterator it=m_lstConnectedObj.begin();it!=m_lstConnectedObj.end();it++)
		{
			TNetObj *poConnectedObj = (TNetObj*)(*it);
			if (poConnectedObj->ForceClose())
				OnDisconnected(poConnectedObj);
		}

		for (std::list<TNetObj*>::iterator it=m_lstAcceptObj.begin();it!=m_lstAcceptObj.end();it++)
		{
			TNetObj *poAcceptObj = (TNetObj*)(*it);
			if (poAcceptObj->ForceClose())
				delete poAcceptObj;
		}

		//m_poNetIocp->End();
		CNetIocp2::End();
		m_poListenObj->ForceClose();

		//delete m_poNetIocp;
		delete m_poListenObj;

		m_lstAcceptObj.clear();
		m_lstConnectedObj.clear();

		DeleteCriticalSection(&m_csAccept);
		DeleteCriticalSection(&m_csConnect);
	}

	SOCKET GetListenSocket(VOID) { return m_poListenObj->GetSocket(); }

private:
	std::list<TNetObj*> m_lstAcceptObj;
	std::list<TNetObj*> m_lstConnectedObj;
	TNetObj *m_poListenObj;
	//CNetIocp<TNetObj> *m_poNetIocp;
	DWORD m_dwAcceptPoolCnt;
	CRITICAL_SECTION m_csAccept;
	CRITICAL_SECTION m_csConnect;

protected:
	virtual VOID OnConnected(TNetObj *poNetObj) = 0;
	virtual VOID OnDisconnected(TNetObj *poNetObj) = 0;
	virtual VOID OnRead(TNetObj *poNetObj, BYTE *pReadBuf, DWORD dwLen) = 0;
	virtual VOID OnWrite(TNetObj *poNetObj, DWORD dwLen) = 0;

	VOID OnIoDisconnected(TNetObj *poNetObj)
	{
		EnterCriticalSection(&m_csConnect);
		m_lstConnectedObj.remove(poNetObj);
		LeaveCriticalSection(&m_csConnect);
		OnDisconnected(poNetObj);
		delete poNetObj;
	}

	VOID OnIoConnected(TNetObj *poNetObj)
	{
		EnterCriticalSection(&m_csAccept);
		m_lstAcceptObj.remove(poNetObj);
		LeaveCriticalSection(&m_csAccept);
		EnterCriticalSection(&m_csConnect);
		m_lstConnectedObj.push_back(poNetObj);
		LeaveCriticalSection(&m_csConnect);
		OnConnected(poNetObj);
	}

	VOID OnIoNewAcceptObj(TNetObj *poNetObj)
	{
		EnterCriticalSection(&m_csAccept);
		m_lstAcceptObj.push_back(poNetObj);
		LeaveCriticalSection(&m_csAccept);
	}

	VOID OnIoRead(TNetObj *poNetObj, DWORD dwLen)
	{
		BOOL bReadBufRet = FALSE;
		CManagedBufSP Buf;
		DWORD dwPacketLen = 0;

		while (bReadBufRet = poNetObj->ReadPacket(Buf->m_aucBuf, dwLen, dwPacketLen))
		{
			if (dwPacketLen > 0)
				OnRead(poNetObj, Buf->m_aucBuf, dwPacketLen);
			else
			{
				// ��Ŷ�� �����Ǿ��� ���� ó�� (���� ����)
				poNetObj->ForceClose();
				break;
			}
		}
	}

	VOID OnIoWrite(TNetObj *poNetObj, DWORD dwLen)
	{
		OnWrite(poNetObj, dwLen);
	}

	//VOID OnIo(BOOL bSucc, DWORD dwNumOfByteTransfered, ULONG_PTR pCompletionKey, OVERLAPPED *pol)
	//{
	//	CNetIoStatus *ponios = (CNetIoStatus*) pol;
	//	if (ponios)
	//	{
	//		TNetObj *poNetObj = (TNetObj*) ponios->m_poObject;
	//		CManagedBufSP Buf;
	//		DWORD dwPacketLen = 0;
	//		BOOL bReadBufRet = FALSE;

	//		switch (ponios->m_eIO)
	//		{
	//		case IO_ACCEPT:
	//			m_lstAcceptObj.remove(poNetObj);
	//			m_lstConnectedObj.push_back(poNetObj);
	//			OnConnected(poNetObj);
	//			break;
	//		case IO_NEW_ACCEPTOBJ:
	//			m_lstAcceptObj.push_back(poNetObj);
	//			break;
	//		case IO_DISCONNECT:
	//			m_lstConnectedObj.remove(poNetObj);
	//			OnDisconnected(poNetObj);
	//			delete poNetObj;
	//			break;
	//		case IO_READ:
	//			while (bReadBufRet = poNetObj->ReadPacket(Buf->m_aucBuf, ponios->m_dwNumOfByteTransfered, dwPacketLen))
	//			{
	//				if (dwPacketLen > 0)
	//					OnRead(poNetObj, Buf->m_aucBuf, dwPacketLen);
	//				else
	//				{
	//					// ��Ŷ�� �����Ǿ��� ���� ó�� (���� ����)
	//					poNetObj->ForceClose();
	//					break;
	//				}
	//			}
	//			break;
	//		case IO_WRITE:
	//			OnWrite(poNetObj, ponios->m_dwNumOfByteTransfered);
	//			break;
	//		}

	//		delete ponios;
	//	}
	//}
};
