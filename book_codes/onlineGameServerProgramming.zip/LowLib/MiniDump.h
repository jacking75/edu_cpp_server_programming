#pragma once

class CMiniDump
{
public:
	static BOOL Begin(VOID);
	static BOOL End(VOID);
};
