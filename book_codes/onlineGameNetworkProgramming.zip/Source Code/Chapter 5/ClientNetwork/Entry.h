#ifndef  __Entry_H
#define  __Entry_H

#include <Winsock2.h>
#include <TChar.h>

#endif