#ifndef  __Protocol_H
#define  __Protocol_H

enum ProtocolList
{
							PT_CONNECTIONSUCCESS_ACK = 100,
	PT_TESTPACKET_REQ,		PT_TESTPACKET_ACK
};

#endif