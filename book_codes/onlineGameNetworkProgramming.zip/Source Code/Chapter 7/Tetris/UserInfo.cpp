#include "stdafx.h"
#include "Tetris.h"
#include "UserInfo.h"

UserInfo::UserInfo()
	: ready( false ), score( 0 ), gameOver( false )
{
}

UserInfo::~UserInfo()
{
}
