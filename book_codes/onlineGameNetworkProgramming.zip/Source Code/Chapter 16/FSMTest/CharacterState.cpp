#include "stdafx.h"
#include "CharacterState.h"

CharacterState::CharacterState( Character* parent )
	: parentObj( parent )
{
}

CharacterState::~CharacterState()
{
}
