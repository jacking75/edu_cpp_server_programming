#include "Character.h"

Character::Character( SOCKET s )
	: Session( s )
{
}

Character::~Character()
{
}
