//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by GameLoader.rc
//
#define IDD_GAMELOADER_DIALOG           102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDS_FTPCONNECTIONFAILED         104
#define IDS_SUCCESSCONNECT              105
#define IDS_DOWNLOADING                 106
#define IDS_CANCEL                      107
#define IDS_CONNECTTOFTPSERVER          108
#define IDS_CONNECTTOUPDATESERVER       109
#define IDS_UPDATESERVERCONNECTIONFAILED 110
#define IDS_CLOSEDFROMUPDATESERVER      111
#define IDS_EXTRACT                     112
#define IDS_NOTENOUGHDISK               113
#define IDS_FTPGETFILEFAILED            114
#define IDS_UNZIPOPENFAILED             115
#define IDS_RECEIVEPATCHINFO            116
#define IDR_MAINFRAME                   128
#define IDC_MESSAGE                     1000
#define IDC_CURRENTPROGRESS             1001
#define IDC_TOTALPROGRESS               1002
#define IDC_FILENAME                    1003
#define IDC_RECEIVECOUNT                1004
#define IDC_CANCELPATCH                 1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
