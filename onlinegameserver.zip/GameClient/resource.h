//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by GameClient.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_GAMECLIENT_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDD_HELPDLG                     133
#define IDI_ICON1                       134
#define IDI_ICON2                       135
#define IDI_ICON3                       136
#define IDI_ICON4                       137
#define IDI_ICON5                       138
#define IDI_ICON6                       139
#define IDI_ICON7                       140
#define IDC_ID                          1000
#define IDC_NAME                        1001
#define IDC_NICKNAME                    1002
#define IDC_POS                         1003
#define IDC_LEVEL                       1004
#define IDC_STR                         1005
#define IDC_DUR                         1006
#define IDC_HP                          1007
#define IDC_EXP                         1008
#define IDC_EDIT1                       1009
#define IDC_EDIT2                       1010
#define IDC_OUTPUT                      1011
#define IDC_PKEY                        1012
#define IDC_BUTTON1                     1013
#define IDC_RANDOMMOVE                  1013
#define IDC_TNAME                       1013
#define IDC_TID                         1014
#define IDC_ID2                         1015
#define IDC_NICKNAME2                   1016
#define IDC_LEVEL2                      1017
#define IDC_DUR2                        1018
#define IDC_HP2                         1019
#define IDC_EXP2                        1020
#define IDC_NAME3                       1021
#define IDC_NAME4                       1022
#define IDC_POS2                        1023
#define IDC_STR2                        1024
#define IDC_POS3                        1025
#define IDC_TNICKNAME                   1025
#define IDC_TPOS                        1026
#define IDC_TLEVEL                      1027
#define IDC_TSTR                        1028
#define IDC_TDUR                        1029
#define IDC_THP                         1030
#define IDC_TEXP                        1031
#define IDC_TPKEY                       1032
#define IDC_ID4                         1033
#define IDC_NICKNAME4                   1034
#define IDC_LEVEL4                      1035
#define IDC_DUR4                        1036
#define IDC_HP4                         1037
#define IDC_EXP4                        1038
#define IDC_NAME5                       1039
#define IDC_NAME6                       1040
#define IDC_POS5                        1041
#define IDC_STR4                        1042
#define IDC_NAME7                       1043
#define IDC_NAME8                       1044
#define IDC_POS6                        1045
#define IDC_NNAME                       1046
#define IDC_NPOS                        1047
#define IDC_NKEY                        1048
#define IDC_NSTATE                      1049
#define IDC_TYPE                        1050
#define IDC_NTYPE                       1050
#define IDC_HELPDLG                     1051
#define IDC_COLMYUSER                   1052
#define IDC_COLMYUSER2                  1053
#define IDC_COLMYUSER3                  1054
#define IDC_COLMYUSER4                  1055
#define IDC_COLMYUSER5                  1056
#define IDC_COLMYUSER6                  1057
#define IDC_COLMYUSER7                  1058

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        141
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1053
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
