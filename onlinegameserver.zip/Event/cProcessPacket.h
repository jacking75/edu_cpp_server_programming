#pragma once

class cProcessPacket
{
public:
	cProcessPacket(void);
	~cProcessPacket(void);
};
