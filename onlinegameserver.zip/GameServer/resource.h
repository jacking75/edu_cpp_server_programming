//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by GameServer.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_GameServerTYPE              129
#define IDB_BITMAP1                     129
#define ID_SERVER_START                 32771
#define ID_SERVER_STOP                  32772
#define ID_CONNECT_NPCSERVER            32773
#define ID_SERVER_CREATETEMPPLAYER      32775
#define ID_SERVER_DESTROYTEMPPLAYER     32777

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32778
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
