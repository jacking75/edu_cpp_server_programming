#include "StdAfx.h"
#include ".\cnpcmanager.h"
#include "cDetectNpc.h"
#include "cNormalNpc.h"

IMPLEMENT_SINGLETON( cNpcManager );

cNpcManager::cNpcManager(void)
{
	m_dwGenerateNpcKey = 0;
	srand( GetTickCount()  );
}

cNpcManager::~cNpcManager(void)
{
	DestroyNpc();
}

bool cNpcManager::CreateNpc( eNpcType NpcType , DWORD dwNpcCnt )
{
	cNpc* pNpc = NULL;
   	for( int i = 0 ; i < (int)dwNpcCnt ; i++ )
	{
		if( DETECT_NPC == NpcType ) 
			pNpc = new cDetectNpc;
		else if( NORMAL_NPC == NpcType ) 
			pNpc = new cDetectNpc;
		if( NULL == pNpc )
			return false;
		pNpc->SetTempNpcInfo();
		pNpc->SetType( NpcType );
		AddNpc( pNpc );
	}
	return true;
}

bool cNpcManager::DestroyNpc()
{
	cMonitor::Owner lock( m_csNpc );
	NPC_IT npc_it;
	for( npc_it = m_mapNpc.begin() ; npc_it != m_mapNpc.end() ; npc_it++ )
	{
		cNpc* pNpc = npc_it->second;
		delete pNpc;
	}
	m_mapNpc.clear();
	return true;
}

bool cNpcManager::AddNpc( cNpc* pNpc )
{
	cMonitor::Owner lock( m_csNpc );
	NPC_IT npc_it;
	npc_it = m_mapNpc.find( pNpc->GetKey() );
	//�̹� ����Ű�� NPC�� �߰��Ǿ� �ִ�.
	if( npc_it != m_mapNpc.end() )
	{
		LOG( LOG_ERROR_LOW ,
			"SYSTEM | cNpcManager::AddNpc() | NpcKey(%d)�� �̹� m_mapNpc�� �����ϰ� �ֽ��ϴ�.",
			pNpc->GetKey() );
		return false;
	}

	m_mapNpc.insert( NPC_PAIR( pNpc->GetKey() , pNpc ) );
	return true;
}

bool cNpcManager::RemoveNpc( DWORD dwNpcKey )
{
	cMonitor::Owner lock( m_csNpc );
	NPC_IT npc_it;
	npc_it = m_mapNpc.find( dwNpcKey );
	//����Ű�� NPC�� �������� �ʴ´�.
	if( npc_it == m_mapNpc.end() )
	{
		LOG( LOG_ERROR_LOW ,
			"SYSTEM | cNpcManager::RemoveNpc() | NpcKey(%d)�� m_mapNpc�� �������� �ʽ��ϴ�.",
			dwNpcKey );
		return false;
	}

	m_mapNpc.erase( npc_it );
	return true;
}

cNpc* cNpcManager::FindNpc( DWORD dwNpcKey )
{
	cMonitor::Owner lock( m_csNpc );
    NPC_IT npc_it;
	npc_it = m_mapNpc.find( dwNpcKey );
	//����Ű�� NPC�� �������� �ʴ´�.
	if( npc_it == m_mapNpc.end() )
	{
		LOG( LOG_ERROR_LOW ,
			"SYSTEM | cNpcManager::FindNpc() | NpcKey(%d)�� m_mapNpc�� �������� �ʽ��ϴ�.",
			dwNpcKey );
		return NULL;
	}
	return (cNpc*)npc_it->second;
}

void cNpcManager::UpdateNpc()
{
	cMonitor::Owner lock( m_csNpc );
	NPC_IT npc_it;
	for( npc_it = m_mapNpc.begin() ; npc_it != m_mapNpc.end() ; npc_it++ )
	{
		cNpc* pNpc = (cNpc*)npc_it->second;
		pNpc->OnProcess();
	}
}

void cNpcManager::GatherVBuffer_NpcInfo()
{
	cMonitor::Owner lock( m_csNpc );
	NPC_IT npc_it;
	VBuffer()->Init();
	VBuffer()->SetShort( NPC_NpcInfo_VSn );
	VBuffer()->SetShort( (short)m_mapNpc.size() );
	for( npc_it = m_mapNpc.begin() ; npc_it != m_mapNpc.end() ; npc_it++ )
	{
		cNpc* pNpc = (cNpc*)npc_it->second;
		VBuffer()->SetInteger( pNpc->GetKey() );
		VBuffer()->SetInteger( pNpc->GetPos() );
		VBuffer()->SetInteger( (int)pNpc->GetType() );
		VBuffer()->SetString( pNpc->GetName() );
	}
	
}
void cNpcManager::GatherVBuffer_UpdateNpc()
{
	cMonitor::Owner lock( m_csNpc );
	NPC_IT npc_it;
	VBuffer()->Init();
	VBuffer()->SetShort( NPC_UpdateNpc_VSn );
	VBuffer()->SetShort( (short)m_mapNpc.size() );
	for( npc_it = m_mapNpc.begin() ; npc_it != m_mapNpc.end() ; npc_it++ )
	{
		cNpc* pNpc = (cNpc*)npc_it->second;
		VBuffer()->SetInteger( pNpc->GetKey() );
		VBuffer()->SetInteger( pNpc->GetPos() );
		VBuffer()->SetInteger( (int)pNpc->GetState() );
	}
	
}